﻿from pdfminer.high_level import extract_text
import sys
if len(sys.argv) != 3:
    print("usage: extract_text.py input.pdf output.txt")
    sys.exit(2)
inp, outp = sys.argv[1], sys.argv[2]
text = extract_text(inp)
open(outp, "w", encoding="utf-8").write(text)
print("DONE")
