#!/bin/sh
rm -rf 0/*\.* constant/polyMesh processor* dynamicCode
cp -r 0.org/* 0/ 2>/dev/null || true
