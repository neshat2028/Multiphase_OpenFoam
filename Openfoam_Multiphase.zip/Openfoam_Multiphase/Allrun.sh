#!/bin/sh
set -e
foamDictionary -entry application -set interFoam system/controlDict >/dev/null 2>&1 || true
blockMesh
setFields
interFoam -parallel 2>/dev/null || interFoam
