OpenFOAM compressible two-phase (VOF) pipe case based on:
E3S Web of Conferences 320, 04016 (2021) ? Numerical Simulation of Multiphase Flow Structures in OpenFOAM.

Key setup:
- Solver: compressibleInterFoam
- Geometry: pipe section; D = 25.4 mm, L/D = 214 (L = 5.4356 m). Approximated as rectangular duct of height = D and width = D.
- Inlet patches split: inletLiquid (bottom half), inletGas (top half)
- Outlet: totalPressure p0=1 atm
- T inlet: 293.15 K
- AMR: dynamicRefineFvMesh on alpha.water up to 1e6 cells (maxRefinement=2 here)
- Fluids: water (998 kg/m3, mu=1e-3), air (perfectGas, mu=1.8e-5), sigma=0.072 N/m
- Default regime velocities from paper: Reg=832, Rel=705 -> Ug=0.491339 m/s, Ul=0.027756 m/s

Switching regimes (per paper):
- Stratified-wave: Reg=16000, Rel=1500 -> set inletGas and inletLiquid U accordingly.
- Plug: Reg=4000, Rel=17000 -> also apply 10 Hz inlet pulsation (requires timeVaryingValue BC or coded BC; not included by default).
- Annular: Reg=28000, Rel=17000 -> set U accordingly.

Run sequence:
- Windows PowerShell: .\\Allrun.ps1
- Linux: blockMesh; setFields; compressibleInterFoam

Note: For exact cylindrical geometry and AMR behavior as paper (Salome + adaptive up to 1e6), consider snappyHexMesh or imported mesh. This case approximates with a rectangular duct for in-repo reproducibility.
